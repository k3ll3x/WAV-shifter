#!/bin/bash
./a.out audio.wav &
aplay new.wav
